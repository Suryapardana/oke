const donasiTEXT = (nama, nomor) => {
let teks = `Tolong Donasinya kak!

TYPE : GOPAY
A.N: ${nama}
NO: ${nomor}

[ Metode Pembayaran Bot ]`
    return teks
};

exports.donasiTEXT = donasiTEXT;